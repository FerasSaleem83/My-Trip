// ignore_for_file: must_be_immutable, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart'; // استيراد الحزمة الجديدة
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';

class InformationPlace extends StatefulWidget {
  final String place_name;
  final List<String> imageUrls;
  final double latitude;
  final double longitude;
  final int number_Visitors;
  final int number_chairs_avilable;
  final int from_budget;
  final int to_budget;

  bool islogin = true;

  InformationPlace({
    required this.place_name,
    required this.imageUrls,
    required this.latitude,
    required this.longitude,
    required this.number_Visitors,
    required this.number_chairs_avilable,
    required this.from_budget,
    required this.to_budget,
    Key? key,
  }) : super(key: key);

  @override
  State<InformationPlace> createState() => _InformationPlaceState();
}

class _InformationPlaceState extends State<InformationPlace> {
  int _currentIndex = 0;
  GoogleMapController? mapController;
  Set<Marker> markers = {};

  @override
  void initState() {
    super.initState();
    markers.add(
      Marker(
        markerId: const MarkerId('stored_location'),
        position: LatLng(widget.latitude, widget.longitude),
        infoWindow: InfoWindow(
          title: widget.place_name,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: StyleAppBar(title: ' اسم المكان: ${widget.place_name}'),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: BackgroundColor(),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Container(
                color: const Color.fromARGB(24, 0, 101, 7),
                child: Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: CarouselSlider(
                      options: CarouselOptions(
                        height: 300.0,
                        aspectRatio: 16 / 9,
                        viewportFraction: 0.8,
                        initialPage: _currentIndex,
                        enableInfiniteScroll: true,
                        reverse: false,
                        autoPlay: false,
                        autoPlayInterval: const Duration(seconds: 3),
                        autoPlayAnimationDuration:
                            const Duration(milliseconds: 800),
                        autoPlayCurve: Curves.fastOutSlowIn,
                        enlargeCenterPage: true,
                        onPageChanged: (index, reason) {
                          setState(() {
                            _currentIndex = index;
                          });
                        },
                        scrollDirection: Axis.horizontal,
                      ),
                      items: widget.imageUrls.map((imageUrl) {
                        return Builder(
                          builder: (BuildContext context) {
                            return GestureDetector(
                              onTap: () {},
                              child: SizedBox(
                                width: double.infinity,
                                height: 200,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(70),
                                  child: Image.network(
                                    imageUrl,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (int i = 0; i < widget.imageUrls.length; i++)
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8.0),
                      width: 15.0,
                      height: 15.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentIndex == i ? Colors.white : Colors.grey,
                      ),
                    ),
                ],
              ),
              Text(
                ' عدد الزوار: ${widget.number_Visitors}',
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Text(
                ' سعة المكان: ${widget.number_chairs_avilable}',
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Expanded(
                flex: 2,
                child: GoogleMap(
                  onMapCreated: (controller) {
                    setState(
                      () {
                        mapController = controller;
                      },
                    );
                  },
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      widget.latitude,
                      widget.longitude,
                    ),
                    zoom: 17,
                  ),
                  markers: markers,
                ),
              ),
              const SizedBox(height: 15),
              Container(
                color: Colors.green,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'الميزانية:',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'من: ${widget.from_budget}',
                          style: const TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 25),
                        Text(
                          'إلى: ${widget.to_budget}',
                          style: const TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
