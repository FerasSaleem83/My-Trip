import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:my_trip/screen/rating.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';

class MyBookingsRestaurant extends StatefulWidget {
  const MyBookingsRestaurant({super.key});

  @override
  State<MyBookingsRestaurant> createState() => _MyBookingsRestaurantState();
}

class _MyBookingsRestaurantState extends State<MyBookingsRestaurant> {
  late Stream<List<DocumentSnapshot>> tripsStream;

  _uploadData() {
    setState(() {});
    tripsStream = FirebaseFirestore.instance
        .collection('MyRestaurantBookings')
        .where(
          'email',
          isEqualTo: FirebaseAuth.instance.currentUser!.email,
        )
        .snapshots()
        .map((snapshot) => snapshot.docs);

    setState(() {});
  }

  @override
  void initState() {
    _uploadData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const StyleAppBar(
        title: 'المطاعم المحجوزة',
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: BackgroundColor(),
        ),
        child: StreamBuilder<List<DocumentSnapshot>>(
            stream: tripsStream,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }

              List<DocumentSnapshot> trips = snapshot.data!;

              if (trips.isEmpty) {
                return const Center(
                  child: Text(
                    'ليس لديك حجوزات',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                );
              }

              return Padding(
                padding: const EdgeInsets.all(20),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      if (trips.length == 1)
                        _buildTripCard(trips.first)
                      else
                        CarouselSlider(
                          options: CarouselOptions(
                            height: 750.0,
                            aspectRatio: 10 / 6,
                            viewportFraction: 0.5,
                            reverse: false,
                            autoPlayInterval: const Duration(seconds: 3),
                            enlargeCenterPage: true,
                            scrollDirection: Axis.vertical,
                          ),
                          items: trips
                              .map((trip) => _buildTripCard(trip))
                              .toList(),
                        ),
                    ],
                  ),
                ),
              );
            }),
      ),
    );
  }

  Widget _buildTripCard(DocumentSnapshot trip) {
    String restaurantName = trip['restaurantName'];
    Timestamp timestamp = trip['timeStamp'];
    DateTime dateTime = timestamp.toDate();
    int personNumber = trip['personNumber'];
    String restaurantId = trip['restaurantId'];

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(75.0),
      ),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.black,
            width: 7.0,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(75)),
          color: Colors.white,
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: SizedBox(
            width: 200,
            child: Column(
              children: [
                const Text(
                  'اسم المطعم',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  restaurantName,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Text(
                  'وقت الحجز',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  width: 150,
                  child: Text(
                    '$dateTime',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Text(
                  'عدد الأشخاص $personNumber',
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () async {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Rating(
                            placeId: restaurantId,
                            email:
                                '${FirebaseAuth.instance.currentUser!.email}',
                            placeName: restaurantName,
                            personNumber: personNumber,
                            timeStamp: Timestamp.now(),
                          ),
                        ),
                      );
                      QuerySnapshot querySnapshot = await FirebaseFirestore
                          .instance
                          .collection('MyRestaurantBookings')
                          .where(
                            'email',
                            isEqualTo: FirebaseAuth.instance.currentUser!.email,
                          )
                          .get();
                      for (QueryDocumentSnapshot doc in querySnapshot.docs) {
                        await doc.reference.delete();
                      }
                    },
                    child: const Text('تقييم'))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
