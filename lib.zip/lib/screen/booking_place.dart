// ignore_for_file: public_member_api_docs, sort_constructors_first
// ignore_for_file: use_build_context_synchronously, must_be_immutable

import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:my_trip/screen/booking_restaurant.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';

class BookingPlace extends StatefulWidget {
  double longitude;
  double latitude;
  String placeId;
  String placeName;
  List<String> imageUrls;
  String numberPerson;
  double newBudget;

  BookingPlace({
    Key? key,
    required this.longitude,
    required this.latitude,
    required this.placeId,
    required this.placeName,
    required this.imageUrls,
    required this.numberPerson,
    required this.newBudget,
  }) : super(key: key);

  @override
  State<BookingPlace> createState() => _BookingPlaceState();
}

class _BookingPlaceState extends State<BookingPlace> {
  final TextEditingController numberPersonController = TextEditingController();
  bool isUploading = false;
  int _currentIndex = 0;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void bookingplace() async {
    await FirebaseFirestore.instance
        .collection('trip_budget')
        .doc(widget.placeId)
        .update(
      {
        'number_Visitors': FieldValue.increment(
          int.parse(widget.numberPerson),
        ),
      },
    );

    await FirebaseFirestore.instance
        .collection('trip_budget')
        .doc(widget.placeId)
        .update(
      {
        'number_chairs_avilable': FieldValue.increment(
          int.parse(widget.numberPerson),
        ),
      },
    );

    await _firestore.collection('MyPlaceBookings').add(
      {
        'placeId': widget.placeId,
        'email': FirebaseAuth.instance.currentUser!.email,
        'placeName': widget.placeName,
        'imageUrls': widget.imageUrls,
        'personNumber': int.parse(widget.numberPerson),
        'timeStamp': Timestamp.now(),
      },
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('نجح'),
          content: SizedBox(
            height: 120,
            child: Column(
              children: [
                const Text('تم حجز المكان بنجاح '),
                if (widget.newBudget > 3)
                  Text(
                      '${widget.newBudget.toStringAsFixed(2)} تم حجز المكان بنجاح تبقى من ميزانيتك '),
                const Text('هل تريد حجز مطعم؟ ')
              ],
            ),
          ),
          actions: <Widget>[
            Row(
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookingRestaurant(
                          longitudeOld: widget.longitude,
                          latitudeOld: widget.latitude,
                          numberPerson: widget.numberPerson,
                          newBudget: widget.newBudget,
                        ),
                      ),
                    );
                  },
                  child: const Text('نعم'),
                ),
                const SizedBox(width: 25),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pop(context);
                  },
                  child: const Text('لا'),
                ),
              ],
            )
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const StyleAppBar(title: 'صفحة حجز المكان'),
      body: Container(
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: BackgroundColor(),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  'الميزانية المتبقية: ${widget.newBudget.toStringAsFixed(2)} دينار',
                  style: const TextStyle(color: Colors.white),
                ),
                Container(
                  color: const Color.fromARGB(24, 0, 101, 7),
                  child: Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(15),
                      child: CarouselSlider(
                        options: CarouselOptions(
                          height: 300.0,
                          aspectRatio: 16 / 9,
                          viewportFraction: 0.8,
                          initialPage: _currentIndex,
                          enableInfiniteScroll: true,
                          reverse: false,
                          autoPlay: false,
                          autoPlayInterval: const Duration(seconds: 3),
                          autoPlayAnimationDuration:
                              const Duration(milliseconds: 800),
                          autoPlayCurve: Curves.fastOutSlowIn,
                          enlargeCenterPage: true,
                          onPageChanged: (index, reason) {
                            setState(() {
                              _currentIndex = index;
                            });
                          },
                          scrollDirection: Axis.horizontal,
                        ),
                        items: widget.imageUrls.map((imageUrl) {
                          return Builder(
                            builder: (BuildContext context) {
                              return GestureDetector(
                                onTap: () {},
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 200,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(70),
                                    child: Image.network(
                                      imageUrl,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                if (isUploading)
                  const CircularProgressIndicator(
                    color: Colors.blue,
                  ),
                if (!isUploading)
                  ElevatedButton(
                    onPressed: bookingplace,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 114, 129, 172),
                      textStyle: const TextStyle(
                        color: Colors.white,
                      ),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.all(25),
                    ),
                    child: const Text('حجز المكان'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
