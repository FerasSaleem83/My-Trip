// ignore_for_file: must_be_immutable, use_build_context_synchronously

import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:my_trip/screen/information_restaurant.dart';
import 'package:my_trip/screen/splash_screen.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';

class BookingRestaurant extends StatefulWidget {
  String numberPerson;
  double newBudget;
  double longitudeOld;
  double latitudeOld;

  BookingRestaurant({
    Key? key,
    required this.numberPerson,
    required this.newBudget,
    required this.longitudeOld,
    required this.latitudeOld,
  }) : super(key: key);

  @override
  State<BookingRestaurant> createState() => _BookingRestaurantState();
}

class _BookingRestaurantState extends State<BookingRestaurant> {
  final TextEditingController numberPersonController = TextEditingController();
  bool isUploading = false;
  late Stream<List<DocumentSnapshot>> tripsStream;
  final _isUploading = false;

  double _calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double p = 0.017453292519943295;
    final a = 0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a)); // 2 * R * asin...
  }

  Future<List<DocumentSnapshot>> _fetchAndFilterRestaurants() async {
    QuerySnapshot querySnapshot =
        await FirebaseFirestore.instance.collection('restaurant_budget').get();
    List<DocumentSnapshot> docs = querySnapshot.docs;
    docs = docs.where((doc) {
      double lat = doc['latitude'];
      double lon = doc['longitude'];
      double distance =
          _calculateDistance(widget.latitudeOld, widget.longitudeOld, lat, lon);
      return distance <= 5; // 5 kilometers range
    }).toList();
    docs.sort((a, b) {
      double latA = a['latitude'];
      double lonA = a['longitude'];
      double latB = b['latitude'];
      double lonB = b['longitude'];
      double distanceA = _calculateDistance(
          widget.latitudeOld, widget.longitudeOld, latA, lonA);
      double distanceB = _calculateDistance(
          widget.latitudeOld, widget.longitudeOld, latB, lonB);
      return distanceA.compareTo(distanceB);
    });
    return docs;
  }

  void bookingrestaurant(String restaurantId, String restaurantName,
      List<String> imageUrls) async {
    try {
      await FirebaseFirestore.instance
          .collection('restaurant_budget')
          .doc(restaurantId)
          .update(
        {
          'number_Visitors': FieldValue.increment(
            int.parse(widget.numberPerson),
          ),
        },
      );

      await FirebaseFirestore.instance
          .collection('restaurant_budget')
          .doc(restaurantId)
          .update(
        {
          'number_chairs_avilable': FieldValue.increment(
            int.parse(widget.numberPerson),
          ),
        },
      );

      await FirebaseFirestore.instance.collection('MyRestaurantBookings').add(
        {
          'restaurantId': restaurantId,
          'email': FirebaseAuth.instance.currentUser!.email,
          'restaurantName': restaurantName,
          'imageUrls': imageUrls,
          'personNumber': int.parse(widget.numberPerson),
          'timeStamp': Timestamp.now(),
        },
      );

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('نجح'),
            content: const SizedBox(
              height: 120,
              child: Column(
                children: [
                  Text('تم حجز المطعم بنجاح '),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pop(context);
                },
                child: const Text('تم'),
              )
            ],
          );
        },
      );
    } catch (e) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('خطأ'),
            content: Text('حدث خطأ أثناء الحجز: $e'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('حسناً'),
              )
            ],
          );
        },
      );
    }
  }

  @override
  void initState() {
    super.initState();
    tripsStream = FirebaseFirestore.instance
        .collection('restaurant_budget')
        .snapshots()
        .asyncMap((snapshot) async {
      List<DocumentSnapshot> filteredDocs = await _fetchAndFilterRestaurants();
      return filteredDocs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: StyleAppBar(
          title:
              'حجز المطعم بميزانية ${widget.newBudget.toStringAsFixed(2)} دينار'),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: BackgroundColor(),
        ),
        child: StreamBuilder<List<DocumentSnapshot>>(
          stream: tripsStream,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const SplashScreen();
            } else if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            } else if (_isUploading) {
              return const CircularProgressIndicator();
            } else if (snapshot.hasData || !_isUploading) {
              List<DocumentSnapshot> trips = snapshot.data!;
              if (trips.isEmpty) {
                return const Center(
                  child: Text('لا يوجد مطاعم ضمن 5 كيلومترات'),
                );
              }
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 1, // عدد الأعمدة
                      mainAxisSpacing: 2, // المسافة العمودية بين الصفوف
                      childAspectRatio: 2,
                      mainAxisExtent: 350,
                    ),
                    itemCount: (trips.length / 2).ceil(), // عدد الصفوف
                    itemBuilder: (context, index) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: trips
                            .sublist(
                          index * 2,
                          (index * 2) + 2 > trips.length
                              ? trips.length
                              : (index * 2) + 2,
                        )
                            .map((trip) {
                          String restaurantName = trip['restaurant_name'];
                          final List<String> imageUrls =
                              (trip['image_urls'] as List).cast<String>();
                          double latitude = trip['latitude'];
                          double longitude = trip['longitude'];
                          int numberVisitors = trip['number_Visitors'];
                          int restaurantCapacity = trip['restaurant_capacity'];
                          int fromBudget = trip['budget'];
                          String restaurantId = trip['restaurantId'];

                          return InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => InformationRestaurant(
                                    restaurant_name: restaurantName,
                                    imageUrls: imageUrls,
                                    latitude: latitude,
                                    longitude: longitude,
                                    number_Visitors: numberVisitors,
                                    restaurant_capacity: restaurantCapacity,
                                    budget: fromBudget,
                                    restaurantId: restaurantId,
                                  ),
                                ),
                              );
                            },
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(75.0),
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 6.0,
                                  ),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(35)),
                                  gradient: const LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [
                                      Colors.white,
                                      Colors.white,
                                    ],
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: SizedBox(
                                    width: 160,
                                    child: Column(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: Colors.black,
                                              width: 4.0,
                                            ),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(100)),
                                            gradient: const LinearGradient(
                                              begin: Alignment.bottomCenter,
                                              end: Alignment.topCenter,
                                              colors: [
                                                Colors.white,
                                                Colors.white,
                                              ],
                                            ),
                                          ),
                                          child: CircleAvatar(
                                            backgroundImage:
                                                NetworkImage(imageUrls[0]),
                                            radius: 75,
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 20, 1, 119),
                                          ),
                                        ),
                                        Text(
                                          restaurantName,
                                          style: const TextStyle(
                                            fontSize: 23,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                        ElevatedButton(
                                          onPressed: () => bookingrestaurant(
                                              restaurantId,
                                              restaurantName,
                                              imageUrls),
                                          child: const Text('حجز'),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
              );
            } else {
              return const Center(
                child: Text('لا يوجد بيانات'),
              );
            }
          },
        ),
      ),
    );
  }
}
