import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:my_trip/screen/booking_place.dart';
import 'package:my_trip/screen/information_place.dart';
import 'package:my_trip/screen/mybookings.dart';
import 'package:my_trip/screen/splash_screen.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';
import 'package:my_trip/style/drawer.dart';

class UserPage extends StatefulWidget {
  const UserPage({Key? key}) : super(key: key);

  @override
  State<UserPage> createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  final TextEditingController budgetFromController = TextEditingController();
  final TextEditingController numberPersonController = TextEditingController();
  GoogleMapController? mapController;
  Set<Marker> markers = {};
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool markerTappedOnce = false;
  int _currentIndex = 0;
  late Stream<List<DocumentSnapshot>> tripsStream;
  late Future<DocumentSnapshot<Map<String, dynamic>>> futureBuilder;
  double? distanceInMeters;
  double? cost;

  @override
  void initState() {
    super.initState();
    _uploadData();
    futureBuilder = getUsers();
  }

  _uploadData() {
    setState(() {});
    tripsStream = FirebaseFirestore.instance
        .collection('trip_budget')
        .snapshots()
        .map((snapshot) => snapshot.docs);

    setState(() {});
  }

  void fetchLocations(int budgetValue) async {
    int numberOfPersons = int.parse(numberPersonController.text.trim());
    double personCost = numberOfPersons * 2;
    double adjustedBudget = budgetValue - personCost;

    if (adjustedBudget < 0) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('خطأ'),
          content: const Text('الميزانية غير كافية بعد خصم تكلفة الأشخاص'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    FirebaseFirestore.instance
        .collection('trip_budget')
        .where('from_budget', isLessThanOrEqualTo: adjustedBudget)
        .get()
        .then((QuerySnapshot querySnapshot) {
      setState(() {
        markers.clear();
      });
      for (var doc in querySnapshot.docs) {
        double latitude = doc['latitude'];
        double longitude = doc['longitude'];
        String placeName = doc['place_name'];
        int chairsAvilable = doc['number_chairs_avilable'];
        String placeId = doc['placeId'];
        final List<String> imageUrls =
            (doc['image_urls'] as List).cast<String>();

        double distance = Geolocator.distanceBetween(
            position.latitude, position.longitude, latitude, longitude);
        setState(() {
          distanceInMeters = distance;
          cost = (distanceInMeters! / 5000) * 2;
          double totalCost = personCost + cost!;
          double remainingBudget = adjustedBudget - cost!;
          if (totalCost <= budgetValue && chairsAvilable >= numberOfPersons) {
            markers.add(Marker(
              markerId: MarkerId(doc.id),
              position: LatLng(latitude, longitude),
              infoWindow: InfoWindow(
                title: placeName,
                snippet: 'تكلفة الذهاب: ${cost!.toStringAsFixed(2)} دينار',
                onTap: () {
                  if (markerTappedOnce) {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('الرسالة'),
                        content: const Text('هل تريد الحجز؟؟؟'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BookingPlace(
                                    longitude: longitude,
                                    latitude: latitude,
                                    placeId: placeId,
                                    placeName: placeName,
                                    imageUrls: imageUrls,
                                    numberPerson:
                                        numberPersonController.text.trim(),
                                    newBudget: remainingBudget,
                                  ),
                                ),
                              );
                            },
                            child: const Text('نعم'),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text('الغاء'),
                          ),
                        ],
                      ),
                    );
                  } else {
                    markerTappedOnce = true;
                  }
                },
              ),
            ));
          }
        });
        adjustCameraPosition();
      }
    });
  }

  void adjustCameraPosition() {
    if (markers.isNotEmpty && mapController != null) {
      LatLngBounds bounds =
          getBounds(markers.map((marker) => marker.position).toList());
      CameraUpdate cameraUpdate = CameraUpdate.newLatLngBounds(bounds, 50);
      mapController!.animateCamera(cameraUpdate);
    }
  }

  LatLngBounds getBounds(List<LatLng> positions) {
    double minLat = double.infinity;
    double maxLat = -double.infinity;
    double minLong = double.infinity;
    double maxLong = -double.infinity;

    for (LatLng position in positions) {
      if (position.latitude < minLat) minLat = position.latitude;
      if (position.latitude > maxLat) maxLat = position.latitude;
      if (position.longitude < minLong) minLong = position.longitude;
      if (position.longitude > maxLong) maxLong = position.longitude;
    }

    return LatLngBounds(
      southwest: LatLng(minLat, minLong),
      northeast: LatLng(maxLat, maxLong),
    );
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getUsers() async {
    User user = FirebaseAuth.instance.currentUser!;
    String userId = user.uid;
    DocumentSnapshot<Map<String, dynamic>> snapshot = await FirebaseFirestore
        .instance
        .collection('users')
        .doc(userId)
        .collection('information')
        .doc(userId)
        .get();

    return snapshot;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: futureBuilder,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SplashScreen();
        } else if (snapshot.hasError) {
          return AlertDialog(
            title: const Text('error'),
            content: Text('error_is: ${snapshot.error}'),
          );
        } else if (snapshot.data == null) {
          return const AlertDialog(
            title: Text('error'),
            content: Text('no_loading_data'),
          );
        } else {
          String email = snapshot.data!['email'];
          String username = snapshot.data!['username'];
          String? imageuser = snapshot.data!['image'];
          return Scaffold(
            drawer: DrawerStyle(
              email: email,
              username: username,
              image: imageuser ??
                  'https://cdn-icons-png.flaticon.com/512/1077/1077114.png',
            ),
            appBar: StyleAppBar(
              title: 'صفحة المستخدم',
              actionBar: IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const MyBookings(),
                      ),
                    );
                  },
                  tooltip: 'حجوزاتي',
                  icon: const Icon(Icons.time_to_leave_sharp)),
            ),
            body: Container(
              height: double.infinity,
              decoration: BoxDecoration(
                gradient: BackgroundColor(),
              ),
              child: StreamBuilder<List<DocumentSnapshot>>(
                stream: tripsStream,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const SplashScreen();
                  } else if (snapshot.hasError) {
                    return AlertDialog(
                      title: const Text('خطأ'),
                      content: Text('الخطأ هو: ${snapshot.error}'),
                    );
                  } else if (snapshot.data == null) {
                    return const AlertDialog(
                      title: Text('خطأ'),
                      content: Text('لا يوجد بيانات'),
                    );
                  } else {
                    List<DocumentSnapshot> trips = snapshot.data!;

                    return Padding(
                      padding: const EdgeInsets.all(15),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      labelText: 'الميزانية',
                                      hintText: 'ادخل الميزانية',
                                      fillColor: Colors.grey[100],
                                      filled: true,
                                      alignLabelWithHint: true,
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Colors.black,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Colors.blue,
                                          width: 2.5,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                        vertical: 5.0,
                                        horizontal: 20,
                                      ),
                                    ),
                                    controller: budgetFromController,
                                    obscureText: false,
                                    keyboardType: TextInputType.number,
                                    validator: (value) {
                                      if (value == null ||
                                          value.trim().isEmpty) {
                                        return 'يرجى ادخال الميزانية';
                                      }
                                      return null;
                                    },
                                    style: const TextStyle(
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 15),
                                Expanded(
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      labelText: 'عدد الأشخاص',
                                      hintText: 'ادخل الأشخاص',
                                      fillColor: Colors.grey[100],
                                      filled: true,
                                      alignLabelWithHint: true,
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Colors.black,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Colors.blue,
                                          width: 2.5,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                        vertical: 5.0,
                                        horizontal: 20,
                                      ),
                                    ),
                                    controller: numberPersonController,
                                    obscureText: false,
                                    keyboardType: TextInputType.number,
                                    validator: (value) {
                                      if (value == null ||
                                          value.trim().isEmpty) {
                                        return 'يرجى ادخال عدد الأشخاص';
                                      }
                                      return null;
                                    },
                                    style: const TextStyle(
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 25),
                            SizedBox(
                              height: 250,
                              width: 375,
                              child: GoogleMap(
                                onMapCreated: (controller) {
                                  setState(() {
                                    mapController = controller;
                                  });
                                },
                                initialCameraPosition: const CameraPosition(
                                  target: LatLng(31.788938, 35.928986),
                                  zoom: 17,
                                ),
                                markers: markers,
                                mapType: MapType.satellite,
                              ),
                            ),
                            const SizedBox(height: 25),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 150,
                                    height: 75,
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color.fromARGB(
                                            255, 33, 68, 243),
                                        foregroundColor: Colors.white,
                                      ),
                                      onPressed: () {
                                        int budgetValue = int.parse(
                                            budgetFromController.text.trim());
                                        fetchLocations(budgetValue);
                                      },
                                      child: const Text('عرض المكان'),
                                    ),
                                  ),
                                  const SizedBox(width: 25),
                                  SizedBox(
                                    width: 150,
                                    height: 75,
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color.fromARGB(
                                            255, 158, 0, 0),
                                        foregroundColor: Colors.white,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          markers.clear();
                                          numberPersonController.clear();
                                          budgetFromController.clear();
                                          distanceInMeters = null;
                                          cost = null;
                                        });
                                      },
                                      child: const Text('مسح'),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            CarouselSlider(
                              options: CarouselOptions(
                                height: 270.0,
                                aspectRatio: 16 / 9,
                                viewportFraction: 0.5,
                                initialPage: _currentIndex,
                                enableInfiniteScroll: true,
                                reverse: false,
                                autoPlay: true,
                                autoPlayInterval: const Duration(seconds: 3),
                                autoPlayCurve: Curves.fastOutSlowIn,
                                enlargeCenterPage: true,
                                onPageChanged: (index, reason) {
                                  setState(() {
                                    _currentIndex = index;
                                  });
                                },
                                scrollDirection: Axis.horizontal,
                              ),
                              items: trips.map(
                                (trip) {
                                  String placeName = trip['place_name'];
                                  final List<String> imageUrls =
                                      (trip['image_urls'] as List)
                                          .cast<String>();
                                  double latitude = trip['latitude'];
                                  double longitude = trip['longitude'];
                                  int numberVisitors = trip['number_Visitors'];
                                  int numberChairsAvilable =
                                      trip['number_chairs_avilable'];
                                  int fromBudget = trip['from_budget'];
                                  int toBudget = trip['to_budget'];

                                  return Builder(
                                    builder: (BuildContext context) {
                                      return InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  InformationPlace(
                                                place_name: placeName,
                                                imageUrls: imageUrls,
                                                latitude: latitude,
                                                longitude: longitude,
                                                number_Visitors: numberVisitors,
                                                number_chairs_avilable:
                                                    numberChairsAvilable,
                                                from_budget: fromBudget,
                                                to_budget: toBudget,
                                              ),
                                            ),
                                          );
                                        },
                                        child: Card(
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(75.0),
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.black,
                                                width: 7.0,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.all(
                                                      Radius.circular(75)),
                                              color: Colors.white,
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: SingleChildScrollView(
                                                child: SizedBox(
                                                  width: 175,
                                                  child: Column(
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage:
                                                            NetworkImage(
                                                                imageUrls[0]),
                                                        radius: 75,
                                                        backgroundColor:
                                                            const Color
                                                                .fromARGB(255,
                                                                20, 1, 119),
                                                      ),
                                                      Text(
                                                        placeName,
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },
                              ).toList(),
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                },
              ),
            ),
          );
        }
      },
    );
  }
}
