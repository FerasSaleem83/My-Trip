// ignore_for_file: non_constant_identifier_names, use_build_context_synchronously, unused_element

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:my_trip/style/appbar.dart';
import 'package:my_trip/style/background_color.dart';

class UpdatePlace extends StatefulWidget {
  final String place_name;
  final int place_capacity;
  final int from_budget;
  final int to_budget;
  final String placeId;

  const UpdatePlace({
    required this.place_name,
    required this.place_capacity,
    required this.from_budget,
    required this.to_budget,
    required this.placeId,
    super.key,
  });

  @override
  State<UpdatePlace> createState() => _UpdatePlaceState();
}

class _UpdatePlaceState extends State<UpdatePlace> {
  final TextEditingController _placeNameController = TextEditingController();
  final TextEditingController _placeCapacityController =
      TextEditingController();
  final TextEditingController _fromBudgetController = TextEditingController();
  final TextEditingController _toBudgetController = TextEditingController();
  bool _isUploading = false;

  @override
  void initState() {
    super.initState();

    _placeNameController.text = widget.place_name;
    _placeCapacityController.text = widget.place_capacity.toString();
    _fromBudgetController.text = widget.from_budget.toString();
    _toBudgetController.text = widget.to_budget.toString();
  }

  void _updatPlace() async {
    try {
      setState(() {
        _isUploading = true;
      });
      await FirebaseFirestore.instance
          .collection('trip_budget')
          .doc(widget.placeId)
          .set({
        'from_budget': int.parse(_fromBudgetController.text.trim()),
        'to_budget': int.parse(_toBudgetController.text.trim()),
        'place_name': _placeNameController.text.trim(),
        'place_capacity': int.parse(_placeCapacityController.text.trim()),
      }, SetOptions(merge: true));

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('نجح'),
            content: const Text('تم تحديث بيانات المكان'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _isUploading = false;
                  });
                },
                child: const Text('تم'),
              ),
            ],
          );
        },
      );
    } on FirebaseAuthException catch (e) {
      setState(() {
        _isUploading = false;
      });
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('خطأ'),
            content: Text(e.message ?? 'Authentication failed'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _isUploading = false;
                  });
                },
                child: const Text('تم'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const StyleAppBar(title: 'تحديث البيانات'),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: BackgroundColor(),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 15),
                  TextFormField(
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    cursorColor: Colors.white,
                    decoration: const InputDecoration(
                      fillColor: Color.fromARGB(255, 114, 139, 164),
                      filled: true,
                      alignLabelWithHint: true,
                      labelText: 'اسم المكان',
                      labelStyle: TextStyle(
                        color: Colors.white,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromARGB(255, 9, 41, 248),
                        ),
                      ),
                    ),
                    controller: _placeNameController,
                  ),
                  const SizedBox(height: 15),
                  TextFormField(
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    cursorColor: Colors.white,
                    decoration: const InputDecoration(
                      fillColor: Color.fromARGB(255, 114, 139, 164),
                      filled: true,
                      alignLabelWithHint: true,
                      labelText: 'سعة المكان',
                      labelStyle: TextStyle(
                        color: Colors.white,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromARGB(255, 9, 41, 248),
                        ),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    autocorrect: false,
                    textCapitalization: TextCapitalization.words,
                    controller: _placeCapacityController,
                  ),
                  const SizedBox(height: 15),
                  TextFormField(
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    cursorColor: Colors.white,
                    decoration: const InputDecoration(
                      fillColor: Color.fromARGB(255, 114, 139, 164),
                      filled: true,
                      alignLabelWithHint: true,
                      labelText: 'الميزانية من',
                      labelStyle: TextStyle(
                        color: Colors.white,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromARGB(255, 9, 41, 248),
                        ),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    autocorrect: false,
                    textCapitalization: TextCapitalization.words,
                    controller: _fromBudgetController,
                  ),
                  const SizedBox(height: 15),
                  TextFormField(
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    cursorColor: Colors.white,
                    decoration: const InputDecoration(
                      fillColor: Color.fromARGB(255, 114, 139, 164),
                      filled: true,
                      alignLabelWithHint: true,
                      labelText: 'الميزانية إلى',
                      labelStyle: TextStyle(
                        color: Colors.white,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromARGB(255, 9, 41, 248),
                        ),
                      ),
                    ),
                    maxLength: 10,
                    keyboardType: TextInputType.number,
                    autocorrect: false,
                    controller: _toBudgetController,
                  ),
                  const SizedBox(height: 15),
                  if (_isUploading)
                    const CircularProgressIndicator(
                      color: Colors.blue,
                    ),
                  if (!_isUploading)
                    ElevatedButton(
                      onPressed: _updatPlace,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 0, 50, 189),
                      ),
                      child: const Text(
                        'تحديث',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
