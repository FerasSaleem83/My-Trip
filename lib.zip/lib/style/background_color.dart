// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';

BackgroundColor() {
  return const LinearGradient(
    begin: Alignment.bottomCenter,
    end: Alignment.topCenter,
    colors: [
      Color.fromARGB(255, 6, 2, 91),
      Color.fromARGB(255, 6, 2, 91),
    ],
  );
}
